package com.eland.uas.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;

@Repository
public interface CustomSystemsResourceRepository {

	List<Role> getResourceBySystemId(Long systemId);
}
