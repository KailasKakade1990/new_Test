package com.eland.uas.reqresp;

import java.util.List;

import com.eland.uas.entity.Resource;

public class ResourceResponse {

	private boolean isSuccess;
	private String message;
	private String errorCode;
	private List<Resource> getAllResources;

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<Resource> getGetAllResources() {
		return getAllResources;
	}

	public void setGetAllResources(List<Resource> getAllResources) {
		this.getAllResources = getAllResources;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
