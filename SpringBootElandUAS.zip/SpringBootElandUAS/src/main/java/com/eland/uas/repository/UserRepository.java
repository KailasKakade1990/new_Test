package com.eland.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eland.uas.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	// void getUserByIdAndPassword(String username, String password);

	//	User  findByAccountNo(Long accountNo);
	User findByUserLogId(String userLogId);

	User findByUserId(Long userId);
	@Query(value="SELECT MAX(account_no) FROM `user`",nativeQuery=true )
	Long findMaxByAccountNo();
	
	
}
