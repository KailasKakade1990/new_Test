package com.eland.uas.entity;

import java.io.Serializable;

public class UserInfoResponse implements Serializable {

	private static final long serialVersionUID = -7618787906279354703L;
	private boolean isSuccess;
	private String message;
	private String errorCode;
	private Object userInfo;
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public Object getUserInfo() {
		return userInfo;
	}
	public void setUserInfo(Object userInfo) {
		this.userInfo = userInfo;
	}
}
