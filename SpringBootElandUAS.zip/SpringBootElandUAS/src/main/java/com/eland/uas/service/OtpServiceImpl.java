package com.eland.uas.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eland.uas.entity.Otp;
import com.eland.uas.entity.SystemOtp;
import com.eland.uas.entity.User;
import com.eland.uas.repository.OtpRepository;

@Service
public class OtpServiceImpl implements OtpService {

	@Autowired
	OtpRepository otpRepository;

	@Override
	public Otp addOtp(String otp, User user, SystemOtp systemOtp) {
		Otp otpObj = new Otp();
		otpObj.setOtp(otp);
		otpObj.setUser(user);
		otpObj.setSystemOtp(systemOtp);
		otpRepository.save(otpObj);
		return otpObj;
	}

}
