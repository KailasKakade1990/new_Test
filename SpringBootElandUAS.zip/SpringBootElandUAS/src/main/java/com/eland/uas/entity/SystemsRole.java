package com.eland.uas.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "system_role")
public class SystemsRole {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "system_role_id")
	private Long systemRoleId;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "system_id")
	private Systems system;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "role_id")
	private Role role;
	@Column(name = "description")
	private String description;
	@Column(name = "is_use",columnDefinition = "BIGINT(20) default 1")
	private Long isUse;
	@Column(name = "user_count",columnDefinition = "int default 0")
	private Long userCount;
	@Column(name = "role_count",columnDefinition = "int default 0")
	private Long roleCount;

	public Long getSystemRoleId() {
		return systemRoleId;
	}

	public void setSystemRoleId(Long systemRoleId) {
		this.systemRoleId = systemRoleId;
	}

	public Systems getSystem() {
		return system;
	}

	public void setSystem(Systems system) {
		this.system = system;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Long getIs_use() {
		return isUse;
	}

	public void setIs_use(Long is_use) {
		this.isUse = is_use;
	}

	public Long getUserCount() {
		return userCount;
	}

	public void setUserCount(Long userCount) {
		this.userCount = userCount;
	}

	public Long getRoleCount() {
		return roleCount;
	}

	public void setRoleCount(Long roleCount) {
		this.roleCount = roleCount;
	}

}
