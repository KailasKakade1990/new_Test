package com.eland.uas.domain;

import java.io.Serializable;

import com.eland.uas.entity.User;

public class UserDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4847786357753768449L;

	private User user;
	private String otpUse;
	private String ipaddress;
	

	public UserDTO(User user, String otpUse,String ipaddress) {
		
		this.user = user;
		this.otpUse = otpUse;
		this.ipaddress=ipaddress;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public String getOtpUse() {
		return otpUse;
	}


	public void setOtpUse(String otpUse) {
		this.otpUse = otpUse;
	}


	public String getIpaddress() {
		return ipaddress;
	}


	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

}
