package com.eland.uas.reqresp;

public class SystemRequest {

	private Long systemId;
	private String name;
	private String description;
	private Long isUse;
	private Long inOtpUse;
	private String clientId;
	private String clientSecret;
	private Long roleCount;
	private Long userCount;
	private Long resourceCount;

	public Long getSystemId() {
		return systemId;
	}

	public void setSystemId(Long systemId) {
		this.systemId = systemId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	public Long getInOtpUse() {
		return inOtpUse;
	}

	public void setInOtpUse(Long inOtpUse) {
		this.inOtpUse = inOtpUse;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public Long getRoleCount() {
		return roleCount;
	}

	public void setRoleCount(Long roleCount) {
		this.roleCount = roleCount;
	}

	public Long getUserCount() {
		return userCount;
	}

	public void setUserCount(Long userCount) {
		this.userCount = userCount;
	}

	public Long getResourceCount() {
		return resourceCount;
	}

	public void setResourceCount(Long resourceCount) {
		this.resourceCount = resourceCount;
	}

	@Override
	public String toString() {
		return "SystemRequest [systemId=" + systemId + ", name=" + name + ", description=" + description + ", isUse="
				+ isUse + ", inOtpUse=" + inOtpUse + ", clientId=" + clientId + ", clientSecret=" + clientSecret
				+ ", roleCount=" + roleCount + ", userCount=" + userCount + ", resourceCount=" + resourceCount + "]";
	}

}
