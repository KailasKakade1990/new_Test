package com.eland.uas.service;

import java.util.List;

import com.eland.uas.entity.User;



public interface PreLoginUserService {

	User save(User user);
	

	List<User> findAll();

	User getUserByUserId(String userid);
	
	boolean sendEmail(String email,String subject,String htmlData);
	
	

}
