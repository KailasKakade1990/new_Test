package com.eland.uas.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.SystemsRole;

@Repository
public interface CustomSystemsRoleRepository {
	List<Long> getEntityBySystemIdWrkGroup(Long SystemId, Long roleId);
	List<BigInteger> getSystemRoleIdbySystemId(Long systemId);
}
