package com.eland.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.SystemsResource;

public interface SystemsResourceRepository extends JpaRepository<SystemsResource, Long>, CustomSystemsResourceRepository {

}
