package com.eland.uas.reqrespmodel;

public class RoleSystemsRequest {

	private String id;
}
