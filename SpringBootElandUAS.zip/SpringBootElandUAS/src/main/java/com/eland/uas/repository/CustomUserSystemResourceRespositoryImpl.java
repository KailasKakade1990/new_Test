package com.eland.uas.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.Resource;

@Repository
@Transactional(readOnly = true)
public class CustomUserSystemResourceRespositoryImpl implements CustomUserSystemResourceRespository{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Resource> getResourceByUserId(String userSystemRoleId) {
		Query query = entityManager.createNativeQuery("select * from resource r inner join system_resource sr on(r.resource_id=sr.resource_id) inner join user_system_resource usr on(sr.resource_detail_id=usr.system_resource_id) where usr.user_system_role_id="+userSystemRoleId+" ", Resource.class);
		//query.getResultList();
		  return query.getResultList();
	}
	
}
