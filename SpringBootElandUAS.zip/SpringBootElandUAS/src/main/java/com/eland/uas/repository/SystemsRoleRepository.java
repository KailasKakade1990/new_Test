package com.eland.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.SystemsRole;

public interface SystemsRoleRepository extends JpaRepository<SystemsRole, Long>, CustomSystemsRoleRepository {


}
