package com.eland.uas.entity;

import java.util.Date;

public class UserInfoRequest {
	
	private Long userId;
	private String userNm;
	private Long telNo;
	private Long mobileNo;
	private Date applyStartDate;
	private Date applyEndDate;
	private String emailAddress;
	private Long isUse;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public Long getTelNo() {
		return telNo;
	}

	public void setTelNo(Long telNo) {
		this.telNo = telNo;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Date getApplyStartDate() {
		return applyStartDate;
	}

	public void setApplyStartDate(Date applyStartDate) {
		this.applyStartDate = applyStartDate;
	}

	public Date getApplyEndDate() {
		return applyEndDate;
	}

	public void setApplyEndDate(Date applyEndDate) {
		this.applyEndDate = applyEndDate;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	@Override
	public String toString() {
		return "UserInfoRequest [userId=" + userId + ", userNm=" + userNm + ", telNo=" + telNo + ", mobileNo="
				+ mobileNo + ", applyStartDate=" + applyStartDate + ", applyEndDate=" + applyEndDate + ", emailAddress="
				+ emailAddress + ", isUse=" + isUse + "]";
	}

}
