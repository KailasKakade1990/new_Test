package com.eland.uas.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.eland.uas.UserRepository1;
import com.eland.uas.entity.User;

@Service
public class JwtUserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	UserRepository1 userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByUserLogId(username);
		if (user == null) {
			throw new UsernameNotFoundException(String.format("NO Of Found with Username '%s'", username));
		}

		return JwtuserFactory.create(user);

	}
}
