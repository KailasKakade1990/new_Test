package com.eland.uas.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "user")
public class User implements Serializable {

	private static final long serialVersionUID = 189383434659129052L;

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	@Column(name = "user_id")
	private Long userId;
	@Column(name = "account_no")
	private Long accountNo;
	@Column(name = "user_log_id",unique = true)
	private String userLogId;
	@Column(name = "user_name")
	private String userName;
	@Column(name = "password")
	private String password;
	@Column(name = "telephone_no")
	private Long telephone_No;
	@Column(name = "mobile")
	private Long mobile;
	@Column(name = "email")
	private String email;
	@Column(name = "apply_start_date")
	private Date applyStartDate;
	@Column(name = "apply_End_date")
	private Date applyEndDate;
	@Column(name = "is_use",columnDefinition = "BIGINT(20) default 1")
	private Long isUse;
	@Transient
	private String[] roleId;
	@Transient
	private String[] systemId;
	private String ipAddress;
	@JsonIgnore
	@OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
	List<Otp> otp;
	
	
	public String getIpaddress() {
		return ipAddress;
	}

	public List<Otp> getOtp() {
		return otp;
	}

	public void setOtp(List<Otp> otp) {
		this.otp = otp;
	}

	public void setIpaddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	private boolean enabled;

	public User() {

	}

	public User(Long userId, Long accountNo, String userLogId, String userName, String password, Long telephone_No,
			Long mobile, String email, Date applyStartDate, Date applyEndDate, Long isUse,
			Set<UserSystemsRole> userSystemsRole) {
		this.userId = userId;
		this.accountNo = accountNo;
		this.userLogId = userLogId;
		this.userName = userName;
		this.password = password;
		this.telephone_No = telephone_No;
		this.mobile = mobile;
		this.email = email;
		this.applyStartDate = applyStartDate;
		this.applyEndDate = applyEndDate;
		this.isUse = isUse;
	}

	public User(Long accountNo, String userLogId, String userName, String password, Long telephone_No, Long mobile,
			String email, Date applyStartDate, Date applyEndDate, Long isUse) {
		this.accountNo = accountNo;
		this.userLogId = userLogId;
		this.userName = userName;
		this.password = password;
		this.telephone_No = telephone_No;
		this.mobile = mobile;
		this.email = email;
		this.applyStartDate = applyStartDate;
		this.applyEndDate = applyEndDate;
		this.isUse = isUse;
	}


	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}

	public String getUserLogId() {
		return userLogId;
	}

	public void setUserLogId(String userLogId) {
		this.userLogId = userLogId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getTelephone_No() {
		return telephone_No;
	}

	public void setTelephone_No(Long telephone_No) {
		this.telephone_No = telephone_No;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getApplyStartDate() {
		return applyStartDate;
	}

	public void setApplyStartDate(Date applyStartDate) {
		this.applyStartDate = applyStartDate;
	}

	public Date getApplyEndDate() {
		return applyEndDate;
	}

	public void setApplyEndDate(Date applyEndDate) {
		this.applyEndDate = applyEndDate;
	}

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	public String[] getRole_id() {
		return roleId;
	}

	public void setRole_id(String[] role_id) {
		this.roleId = role_id;
	}

	public String[] getSystem_id() {
		return systemId;
	}

	public void setSystem_id(String[] system_id) {
		this.systemId = system_id;
	}

}
