package com.eland.uas.reqrespmodel;

public class UserInfoRequest {

}
